<?php
define('DB_HOST',$DB_HOST);
define('DB_NAME',$DB_NAME);
define('DB_USER',$DB_USER);
define('DB_PASSWORD',$DB_PASSWORD);



?>